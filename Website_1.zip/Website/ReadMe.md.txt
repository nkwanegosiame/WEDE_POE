Project title: POE part1

Student Information: Gosiame Nkwane, ST10511881

Project Overview (complete): Made two proposals of two organizations and research, then chose one to work on and create a Website of the chosen organization. Namely of the organizations are Bobby's Animal Shelter and Eros Florist and the chosen organization is Bobby's Animal Shelter.

Website Goals and Functionality: Bobby's Animal Shelter is to provide homes to lost and stray animals that have been abandoned, abused or neglected, and the organization focuses on the welfare of animals by providing them with food, medical treatment and a safe shelter. The goal of the website is to increase pet adoptions, raise money for the animals, finding volunteers, reuniting missing animals with their owners and to educate the public about animal care are the objectives of an animal shelter website, and to give more information about animals and illnesses that may affect the pet animal.
 
Key features and functionality: Homepage- introduces the site with a heading of the website, it also have the navigation menu and a clear call for action, and image. The About Us page- shares the history of the organization and the mission it intent to do. The products and services page- this page shares the  services the organization provide and the products they also provide. The contact page- this page has the contacts, emails, location of the organization and the phone numbers.

Timeline and milestones: Research made on the 14/08 to 14/08, proposal 15/08 to 15/08, chosen proposal 16/08 to 17/08 and website 18/08 to 19/08

Part 1 Details: create a website using HTML

Sitemap: Index- mission and vision of the organization, About- Brief history, products and services, Contact information

References: Coetzee, M. (2026). Learning Unit 1. WEDE5020.Web Development (Introduction).[Online via internal Virtual Learning Environment (VLE)]. The independent Institute of Education.[Accessed: 19 August 2026]. Earth pet Vet, 2025. The Vital Role of Animals.[image online] Available at: earthpet.co.za (3)PeopleImage, 2023. Discover new visuals with every visit. [image online] Available at: istockphoto.com (4) Earth pet Vet, 2025. The Vital Roles of Animals. [image online] Available at: earthpet.co.za (5) Animal Images, 2026. Animal Shelter Images. [Image online] Available at: stock.adobe.com 


Changelog:
 Added the styles.css
 Updated the styles.css

 Added the javaScript
 Added the enquiry.html
 Added the robots.txt
 Added the sitemap.xml