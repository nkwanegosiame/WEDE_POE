document.getElementById('myButton').addEventListener('click', function() {
    alert('Button was clicked!');

    const successMessage = document.getElementById('success-message');
    successMessage.style.display = 'block';

    const form = document.getElementById('enquiry-form');
    form.reset();

    const fields = ['name', 'email', 'phone'];
    fields.forEach(function(field) {

        const errorElement = document.getElementById(field + '-error');
        errorElement.textContent = '';

        if (field === 'name') {

            const nameInput = document.getElementById('name');
            if (nameInput.value.trim() === '') {

                errorElement.textContent = 'Name is required.';
            }
        }
        if (field === 'email') {

            const emailInput = document.getElementById('email');
            const emailPattern = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

            if (emailInput.value.trim() === '') {

                errorElement.textContent = 'Email is required.';

            } else if (!emailPattern.test(emailInput.value.trim())) {

                errorElement.textContent = 'Please enter a valid email address.';
            }
        }

        if (field === 'phone') {

            const phoneInput = document.getElementById('phone');
            if (phoneInput.value.trim() === '') {

                errorElement.textContent = 'Phone is required.';
            }

        }
    
    });
    
    function clearErrors() {
        fields.forEach(function(field) {
            const errorElement = document.getElementById(field + '-error');
            errorElement.textContent = '';
        });
    }; 

    function validate() {
        let isValid = true;
        fields.forEach(function(field) {
            const errorElement = document.getElementById(field + '-error');
            if (errorElement.textContent !== '') {
                isValid = false;
            }

        });

        return isValid;

        if (fields.nameInput.value.trim().length < 2) {

            fields.nameInput.textContent ="Name must be at least 2 characters long.";
            valid = false;

        }

        if (fields.surnameInput.value.trim().length < 2) {

            fields.surnameInput.textContent ="Surname must be at least 2 characters long.";
            valid = false;

        }

        if (fields.emailInput.value.trim().length < 5) {

            fields.emailInput.textContent ="Email must be at least 5 characters long.";
            valid = false;

        } const emailPattern = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

        if (!emailPattern.test(fields.emailInput.value.trim())) {
            fields.emailInput.textContent ="Please enter a valid email address.";
            valid = false;
        }

        const phonePattern = /^\d{10}$/;

        if (!phonePattern.test(fields.phoneInput.value.trim())) {

            fields.phoneInput.textContent ="Please enter a valid 10-digit phone number.";
            valid = false;
        }
    }

    form.addEventListener('submit', function(event) {

        event.preventDefault();

        clearErrors();

        if (validate()) {
            // Form is valid, you can submit it here
            form.submit();
        }
    });


    form.addEventListener("submit", function(event) {

        event.preventDefault();

        if (validate()) {
            // Form is valid, you can submit it here
            form.submit();

        } else {
            // Form is invalid, show error messages
            const errorElements = document.querySelectorAll(".error");
            errorElements.forEach(function(errorElement) {
                if (errorElement.textContent !== "") {
                    errorElement.style.display = "block";
                } else {
                    errorElement.style.display = "none";
                }
            });
        }

    });

    object.values(fields).forEach(function(field) {
        const errorElement = document.getElementById(field + '-error');
        if (errorElement.textContent !== '') {
            errorElement.style.display = 'block';
        } else {
            errorElement.style.display = 'none';
        }

    });
    
});